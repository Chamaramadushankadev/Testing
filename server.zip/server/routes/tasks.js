import express from 'express';
import Task from '../models/Task.js';
import { authenticate } from '../middleware/auth.js';
import mongoose from 'mongoose';

const router = express.Router();

// Check if database is available
const isDatabaseAvailable = () => {
  return mongoose.connection.readyState === 1;
};

// Get all tasks for user
router.get('/', authenticate, async (req, res) => {
  try {
    // Check database connection
    if (!isDatabaseAvailable()) {
      console.log('Database not available, returning empty array for tasks');
      return res.json([]);
    }

    const { status, priority, goalId } = req.query;
    const filter = { userId: req.user._id };

    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (goalId) filter.goalId = goalId;

    const tasks = await Task.find(filter)
      .populate('goalId', 'title')
      .sort({ dueDate: 1 });
    
    res.json(tasks || []);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    // Return empty array on any error to prevent frontend crashes
    res.json([]);
  }
});

// Get single task
router.get('/:id', authenticate, async (req, res) => {
  try {
    if (!isDatabaseAvailable()) {
      return res.status(503).json({ message: 'Database not available' });
    }

    const task = await Task.findOne({ _id: req.params.id, userId: req.user._id })
      .populate('goalId', 'title');
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json(task);
  } catch (error) {
    console.error('Error fetching task:', error);
    res.status(500).json({ message: 'Error fetching task' });
  }
});

// Create new task
router.post('/', authenticate, async (req, res) => {
  try {
    if (!isDatabaseAvailable()) {
      return res.status(503).json({ 
        message: 'Database not available - running in demo mode',
        error: 'Cannot create tasks without database connection'
      });
    }

    const taskData = {
      ...req.body,
      userId: req.user._id,
      status: req.body.status || 'pending',
      attachments: req.body.attachments || []
    };

    const task = new Task(taskData);
    await task.save();
    
    // Populate the goal information before returning
    await task.populate('goalId', 'title');
    res.status(201).json(task);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(400).json({ 
      message: 'Error creating task',
      error: error.message 
    });
  }
});

// Update task
router.put('/:id', authenticate, async (req, res) => {
  try {
    if (!isDatabaseAvailable()) {
      return res.status(503).json({ 
        message: 'Database not available - running in demo mode',
        error: 'Cannot update tasks without database connection'
      });
    }

    const updateData = { ...req.body };
    
    // If marking as completed, set completedAt
    if (updateData.status === 'completed' && !updateData.completedAt) {
      updateData.completedAt = new Date();
    }
    
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      updateData,
      { new: true, runValidators: true }
    ).populate('goalId', 'title');
    
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json(task);
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(400).json({ 
      message: 'Error updating task',
      error: error.message 
    });
  }
});

// Delete task
router.delete('/:id', authenticate, async (req, res) => {
  try {
    if (!isDatabaseAvailable()) {
      return res.status(503).json({ 
        message: 'Database not available - running in demo mode',
        error: 'Cannot delete tasks without database connection'
      });
    }

    const task = await Task.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ 
      message: 'Error deleting task',
      error: error.message 
    });
  }
});

// Toggle task status
router.patch('/:id/toggle', authenticate, async (req, res) => {
  try {
    if (!isDatabaseAvailable()) {
      return res.status(503).json({ 
        message: 'Database not available - running in demo mode',
        error: 'Cannot toggle task status without database connection'
      });
    }

    const task = await Task.findOne({ _id: req.params.id, userId: req.user._id });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    const updateData = { status: newStatus };
    
    if (newStatus === 'completed') {
      updateData.completedAt = new Date();
    } else {
      updateData.completedAt = null;
    }

    const updatedTask = await Task.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    ).populate('goalId', 'title');

    res.json(updatedTask);
  } catch (error) {
    console.error('Error toggling task:', error);
    res.status(400).json({ 
      message: 'Error toggling task',
      error: error.message 
    });
  }
});

export default router;